from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from app.services import profile_store  # noqa: E402
from app.services.project_manager import deduplicate_project_images  # noqa: E402


def _default_targets() -> list[tuple[str, Path]]:
    targets: list[tuple[str, Path]] = []
    seen_roots: set[Path] = set()

    legacy_root = profile_store.get_legacy_projects_root().resolve()
    if legacy_root.exists():
        targets.append(("legacy", legacy_root))
        seen_roots.add(legacy_root)

    for profile in profile_store.list_profiles():
        root = profile_store.get_profile_projects_root(profile["id"]).resolve()
        if root in seen_roots:
            continue
        targets.append((f"profile:{profile['name']}", root))
        seen_roots.add(root)

    return targets


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Deduplicate project image files by replacing duplicate bytes with hard links.")
    parser.add_argument(
        "--root",
        action="append",
        default=[],
        help="Specific project root to scan. Defaults to the legacy project root plus all profile project roots.",
    )
    parser.add_argument(
        "--project",
        action="append",
        dest="projects",
        default=[],
        help="Restrict deduplication to the specified project name. Repeatable.",
    )
    args = parser.parse_args(argv)

    if args.root:
        targets = [(str(Path(raw_root).expanduser().resolve()), Path(raw_root).expanduser().resolve()) for raw_root in args.root]
    else:
        targets = _default_targets()

    totals = {
        "scanned_roots": len(targets),
        "scanned_projects": 0,
        "scanned_files": 0,
        "duplicates_found": 0,
        "deduplicated_files": 0,
        "already_linked": 0,
        "bytes_reclaimed": 0,
        "skipped": 0,
    }
    results = []

    for label, root in targets:
        result = deduplicate_project_images(root, args.projects or None)
        result["label"] = label
        results.append(result)

        totals["scanned_projects"] += int(result["scanned_projects"])
        totals["scanned_files"] += int(result["scanned_files"])
        totals["duplicates_found"] += int(result["duplicates_found"])
        totals["deduplicated_files"] += int(result["deduplicated_files"])
        totals["already_linked"] += int(result["already_linked"])
        totals["bytes_reclaimed"] += int(result["bytes_reclaimed"])
        totals["skipped"] += len(result["skipped"])

    print(json.dumps({"roots": results, "totals": totals}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())