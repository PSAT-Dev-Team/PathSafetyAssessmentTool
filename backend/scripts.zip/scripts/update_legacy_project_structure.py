from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


BACKEND_ROOT = Path(__file__).resolve().parents[1]


def _load_migration_module():
    module_path = BACKEND_ROOT / "app" / "services" / "legacy_project_migration.py"
    spec = importlib.util.spec_from_file_location("psat_legacy_project_migration", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load migration module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main(argv: list[str] | None = None) -> int:
    migration_module = _load_migration_module()
    parser = argparse.ArgumentParser(
        description=(
            "Update legacy projects to the linked-image structure by replacing copied project images "
            "with hard links back to their source-folder originals where possible."
        )
    )
    parser.add_argument(
        "--legacy-root",
        help="Optional override for the legacy projects root. Defaults to the configured data folder.",
    )
    parser.add_argument(
        "--in-root",
        help="Optional override for the source image root. Defaults to the configured in folder.",
    )
    parser.add_argument(
        "--project",
        action="append",
        dest="projects",
        default=[],
        help="Restrict the migration to the specified legacy project. Repeatable.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what would change without rewriting any project images.",
    )
    parser.add_argument(
        "--no-bootstrap-profiles",
        action="store_true",
        help="Skip creating an empty profiles registry when the gitignored profiles folder is missing.",
    )
    args = parser.parse_args(argv)

    summary = migration_module.migrate_legacy_project_structure(
        legacy_root=Path(args.legacy_root).expanduser().resolve() if args.legacy_root else None,
        in_root=Path(args.in_root).expanduser().resolve() if args.in_root else None,
        project_names=args.projects or None,
        dry_run=bool(args.dry_run),
        bootstrap_profiles=not bool(args.no_bootstrap_profiles),
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())